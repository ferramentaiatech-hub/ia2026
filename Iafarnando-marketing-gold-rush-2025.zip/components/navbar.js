class CustomNavbar extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: block;
                    width: 100%;
                }
                
                nav {
                    background: #1a202c;
                    border-bottom: 1px solid rgba(107, 114, 128, 0.3);
                    padding: 1rem 0;
                    position: fixed;
                    width: 100%;
                    top: 0;
                    z-index: 50;
                }
                
                .dark nav {
                    background: #1a202c;
                }
                
                .container {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 0 1rem;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                
                .logo {
                    font-size: 1.5rem;
                    font-weight: bold;
                    color: #d69e2e;
                }
                
                .logo span {
                    color: white;
                }
                
                .nav-links {
                    display: none;
                }
                
                .nav-links a {
                    color: white;
                    text-decoration: none;
                    transition: color 0.3s;
                }
                
                .nav-links a:hover {
                    color: #d69e2e;
                }
                
                .cta-button {
                    background: #d69e2e;
                    color: #1a202c;
                    padding: 0.5rem 1.5rem;
                    border-radius: 0.5rem;
                    font-weight: bold;
                    text-decoration: none;
                    transition: background-color 0.3s;
                }
                
                .cta-button:hover {
                    background: white;
                }
                
                .mobile-menu {
                    display: none;
                    position: absolute;
                    top: 100%;
                    left: 0;
                    right: 0;
                    background: #1a202c;
                    border-bottom: 1px solid rgba(107, 114, 128, 0.3);
                    padding: 1rem;
                    flex-direction: column;
                    gap: 1rem;
                }
                
                .mobile-menu.active {
                    display: flex;
                }
                
                @media (min-width: 768px) {
                    .nav-links {
                        display: flex;
                        gap: 2rem;
                    }
                }
                
                .menu-button {
                    display: block;
                    background: none;
                    border: none;
                    color: white;
                    cursor: pointer;
                }
                
                @media (max-width: 767px) {
                    .desktop-cta {
                        display: none;
                    }
                }
            </style>
            <nav>
                <div class="container">
                    <div class="logo">Marketing<span>Mastery</span></div>
                    
                    <div class="nav-links">
                        <a href="#beneficios">Benefícios</a>
                        <a href="#produto">Produto</a>
                        <a href="#depoimentos">Depoimentos</a>
                        <a href="#garantia">Garantia</a>
                        <a href="#compra" class="cta-button">
                        Comprar Agora
                    </a>
                    </div>
                    
                    <div class="flex items-center gap-4">
                        <a href="#compra" class="cta-button desktop-cta">
                            Comprar Agora
                        </a>
                        
                        <button class="menu-button md:hidden">
                            <i data-feather="menu"></i>
                    </div>
                </div>
                
                <div class="mobile-menu">
                    <a href="#beneficios">Benefícios</a>
                    <a href="#produto">Produto</a>
                    <a href="#depoimentos">Depoimentos</a>
                        <a href="#garantia">Garantia</a>
                        <a href="#compra" class="cta-button">
                            Comprar Agora
                        </a>
                    </div>
                </div>
            </nav>
        `;

        this.setupMobileMenu();
    }

    setupMobileMenu() {
        const menuButton = this.shadowRoot.querySelector('.menu-button');
        const mobileMenu = this.shadowRoot.querySelector('.mobile-menu');

        if (menuButton && mobileMenu) {
            menuButton.addEventListener('click', () => {
                mobileMenu.classList.toggle('active');
            });
        }
    }
}

customElements.define('custom-navbar', CustomNavbar);