class CustomFooter extends HTMLElement {
    connectedCallback() {
        this.attachShadow({ mode: 'open' });
        this.shadowRoot.innerHTML = `
            <style>
                :host {
                    display: block;
                    width: 100%;
                }
                
                footer {
                    background: black;
                    padding: 2rem 0;
                    border-top: 1px solid rgba(107, 114, 128, 0.3);
                }
                
                .container {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 0 1rem;
                    text-align: center;
                }
                
                .footer-content {
                    color: #9ca3af;
                }
                
                .social-links {
                    display: flex;
                    justify-content: center;
                    gap: 1rem;
                    margin-top: 1rem;
                }
                
                .social-links a {
                    color: #9ca3af;
                    transition: color 0.3s;
                }
                
                .social-links a:hover {
                    color: #d69e2e;
                }
            </style>
            <footer>
                <div class="container">
                    <div class="footer-content">
                        <p>© 2024 Marketing Mastery. Todos os direitos reservados.</p>
                    <div class="social-links">
                        <a href="#" aria-label="Instagram">
                            <i data-feather="instagram"></i>
                        </a>
                        <a href="#" aria-label="Facebook">
                            <i data-feather="facebook"></i>
                        </a>
                        <a href="#" aria-label="LinkedIn">
                            <i data-feather="linkedin"></i>
                        </a>
                        <a href="#" aria-label="Twitter">
                            <i data-feather="twitter"></i>
                        </a>
                        <a href="#" aria-label="YouTube">
                            <i data-feather="youtube"></i>
                        </a>
                    </div>
                </div>
            </footer>
        `;
    }
}

customElements.define('custom-footer', CustomFooter);